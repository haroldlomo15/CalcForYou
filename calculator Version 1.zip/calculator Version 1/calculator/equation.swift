//
//  equation.swift
//  calculator
//
//  Created by Harold  on 1/12/16.
//  Copyright © 2016 Harold . All rights reserved.
//

import UIKit

class equation: UIViewController {


}