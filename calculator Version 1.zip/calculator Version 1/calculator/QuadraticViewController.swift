//
//  QuadraticViewController.swift
//  calculator
//
//  Created by Harold  on 1/20/16.
//  Copyright © 2016 Harold . All rights reserved.
//

import UIKit

class QuadraticViewController: UIViewController {

    @IBOutlet weak var labelsample: UILabel!
    @IBOutlet weak var aText: UITextField!
    @IBOutlet weak var bText: UITextField!
    @IBOutlet weak var cText: UITextField!
   
    
    
    //Built in method for user to touch view to hid keyboard
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func button() {
        
    }
    

}
